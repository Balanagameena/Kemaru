#Before running,please use mouse to get the better result since there is more sensitivy if used in laptop's touchpad

import pygame
import random as r
from settings import *
from input import *
import copy

pygame.init()
predef=[]
gridcolors = [ALMOND, BURLY, SKYBLUE, CORN, VERT, GREY, LIGHTGREY, HOTPINK, IVORY, LIGHTPINK, SALMON,
                  LIGHTSKY, SLATE, LIGHTYELLOW, MAGENTA, SPRINGGREEN, MINT, PEACH,BANANA]

def drawGrid(gameDisplay): #To draw the grid lines
    pygame.draw.rect(gameDisplay, BLACK, (gridPos[0], gridPos[1], 9 * cellSize, 9 * cellSize), 2)
    for x in range(9):
        pygame.draw.line(gameDisplay, BLACK, (gridPos[0] + (x * cellSize), gridPos[1]),
                         (gridPos[0] + (x * cellSize), gridPos[1] + 450))
        pygame.draw.line(gameDisplay, BLACK, (gridPos[0], gridPos[1] + (x * cellSize)),
                         (gridPos[0] + 450, gridPos[1] + +(x * cellSize)))


def RemoveDuplicateelements(arr): #Remove duplicate co-ordinates
    for elem in arr:
        if (arr.count(elem) > 1):
            for j in range(arr.count(elem)):
                arr.remove(elem)

def colored_grid(grid): #To get the grids colored
    coord = copy.deepcopy(grid)

    for k in range(len(grid)):
        for j in range(len(grid[k])):
            x, y = grid[k][j]
            a = x * cellSize + gridPos[0]
            b = y * cellSize + gridPos[1]
            coord[k][j] = (a, b,cellSize,cellSize)
            pygame.draw.rect(gameDisplay,gridcolors[k],(coord[k][j]))


def drawOneArea(screen, coords_of_cells,color=BLACK): #To draw the grids
    # coords_of_cells to draw the shapes
    lines_to_draw = []
    # This populates the list "lines_to_draw" with lines
    for x, y in coords_of_cells:
        lines_to_draw.append({((x * cellSize), (y * cellSize)), ((x * cellSize) + cellSize, (y * cellSize))})
        lines_to_draw.append({((x * cellSize), (y * cellSize)), ((x * cellSize), (y * cellSize) + cellSize)})
        lines_to_draw.append(
            {((x * cellSize), (y * cellSize) + cellSize), ((x * cellSize) + cellSize, (y * cellSize) + cellSize)})
        lines_to_draw.append(
            {((x * cellSize) + cellSize, (y * cellSize)), ((x * cellSize) + cellSize, (y * cellSize) + cellSize)})
    # We remove the interior lines
    RemoveDuplicateelements(lines_to_draw)

    # We can now draw the lines to get the outline
    for line in lines_to_draw:
        list_from_set = list(line)
        pygame.draw.line(gameDisplay, color, (gridPos[0] + list_from_set[0][0], gridPos[1] + list_from_set[0][1]),
                         (gridPos[0] + list_from_set[1][0], gridPos[1] + list_from_set[1][1]), 3)

font=pygame.font.SysFont(None,50)

def message_to_screen(msg,color,x,y): #To give the message to the screen
    screen_text=font.render(msg,True,color)
    gameDisplay.blit(screen_text,[x,y])

helpcount='0'

def make_button_rect(window,inactive_color,active_color,coordinates,text,action=None):#To create the buttons and make the button to respond
    global helpcount
    pos=pygame.mouse.get_pos()
    click=pygame.mouse.get_pressed()
    helpcount='0'
    if coordinates[0] < pos[0] < coordinates[0]+coordinates[2] and coordinates[1] < pos[1] < coordinates[1]+coordinates[3]:
        pygame.draw.rect(window, active_color, coordinates)
        font_name = pygame.font.Font('jokerman.ttf', 15)
        font_render_value = font_name.render(text, True, BLACK, active_color)
        make_rect = font_render_value.get_rect()
        make_rect.center = (coordinates[0] + (coordinates[2] // 2), coordinates[1] + (coordinates[3] // 2))
        gameDisplay.blit(font_render_value, make_rect)
        #if click[0]==1 and action !=None:
        if event.type == pygame.MOUSEBUTTONDOWN and action !=None:
            # if the left button is pressed
            if event.button == 1:
                if action=='quit':
                    pygame.quit()
                    quit()
                if action=='newgame':
                    newgame()
                if action=='help':
                    if puzzleset[x][1] != puzone:
                        help()
                        b=helppress()
                    else:
                        pass
    else:
        pygame.draw.rect(window, inactive_color, coordinates)
        font_name = pygame.font.Font('jokerman.ttf', 15)
        font_render_value = font_name.render(text, True, BLACK, inactive_color)
        make_rect = font_render_value.get_rect()
        make_rect.center = (coordinates[0]+(coordinates[2]//2),coordinates[1]+(coordinates[3]//2))
        gameDisplay.blit(font_render_value, make_rect)

def placing_setting(a,b,v): #To place the values inside the grid
    if v!='0':
        font_name = pygame.font.Font('arial.ttf', 20)
        font_render_value = font_name.render(v, True,BLACK,None)
        make_rect = font_render_value.get_rect()
        make_rect.center = (int(gridPos[0]+(a*cellSize)+(cellSize/2)),int(gridPos[1]+(b*cellSize)+(cellSize/2)))
        gameDisplay.blit(font_render_value, make_rect)

def rand_grid_gen(puzzlesolution): #To generate the random values in the grid
    for k in range(len(puzzlesolution)):
        c=r.randint(0, len(puzzlesolution[k])-1)
        predef.append((k,c))
        puzone[k][c]=puzzlesolution[k][c]

def help(): #Help button to populate few values inside the grid
    if puzzleset[x][1] !=puzone:
        for k in range(len(puzzleset[x][1])):
            c=r.randint(0, len(puzzleset[x][1][k])-1)
            for i in range(len(predef)):
                if (k,c) not in predef and puzone[k][c]!=puzzleset[x][1][k][c]:
                    predef.append((k,c))
                    puzone[k][c]=puzzleset[x][1][k][c]
    pygame.display.update()
    
a=0
def helppress(): #Number of times help button is pressed
    global a
    a+=1
    return a

def make_puzzle(gridname): #To form the empty grids and differentiate it colorwise
    colored_grid(gridname)
    for i in range(len(gridname)):
        drawOneArea(gameDisplay, gridname[i])
    drawGrid(gameDisplay)

def fill_puzzle(puzzlename):#Fills the values in the grid
    for i in range(len(puzzlename)):
        for j in range(len(puzzlename)):
            placing_setting(i, j, puzzlename[j][i])

def get_user_input():#to get the input from the user
    pos=pygame.mouse.get_pos()
    click=pygame.mouse.get_pressed()
    x=pos[0]
    y=pos[1]
    number=''
    if gridPos[0] < pos[0] < (gridPos[0] + (9 * cellSize)) and gridPos[1] < pos[1] < (gridPos[1] + (9 * cellSize)):
        x = ((pos[0] + 25) // cellSize)-2
        y = (pos[1] // cellSize)-2
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_1:
                number += str(chr(event.key))
                puzone[y][x]=number
            elif event.key == pygame.K_2:
                number += str(chr(event.key))
                puzone[y][x] = number
            elif event.key == pygame.K_3:
                number += str(chr(event.key))
                puzone[y][x] = number
            elif event.key == pygame.K_4:
                number += str(chr(event.key))
                puzone[y][x] = number
            elif event.key == pygame.K_5:
                number += str(chr(event.key))
                puzone[y][x] = number
            else:
                screen_text = font.render('Only numbers 1-5 is allowed', True, BLUE)
                gameDisplay.blit(screen_text, [100, 300])
    pygame.display.update()

def newgame(): #to take to a new grid
    global completed
    global predef
    global x
    predef=[]
    completed=False
    for i in range(len(puzone)):
        for j in range(len(puzone)):
            puzone[j][i]=puzzero[j][i]
    x = r.randint(0, len(puzzleset) - 1)
    rand_grid_gen(puzzleset[x][1])
    make_puzzle(puzzleset[x][0])
    fill_puzzle(puzzleset[x][2])

def compare_puzzle(): #Compares the user input solution and the actual grid solution
    global completed
    if puzone == puzzleset[x][1]:
        message_to_screen('Completed', RED, 600, 475)
        pygame.display.update()
    else:
        pygame.draw.rect(gameDisplay,WHITE,(600,475,200,50))
        pygame.display.update()

def message_on_screen(fontname,fontsize,text,textcolor,bgcolor,x,y): #To have the message on screen
    font_name = pygame.font.Font(fontname,fontsize)
    font_render_value = font_name.render(text, True,textcolor, bgcolor)
    make_rect = font_render_value.get_rect()
    make_rect.center = (x,y)
    gameDisplay.blit(font_render_value, make_rect)

action=None

#Sets Game Caption & Game Icon
pygame.display.set_caption('KEMARU')
pygame.display.set_icon(pygame.image.load('steps.png'))

#Sets game display screen size and Fill with WHITE Color
gameDisplay = pygame.display.set_mode((WIDTH, HEIGHT))
gameDisplay.fill(WHITE)

puzzleset=[(gridA,puzonesol,puzone),(gridB,puztwosol,puzone),(gridC,puzthreesol,puzone)]
x = r.randint(0, len(puzzleset) - 1)

#First Time Puzzle Generation Handling
rand_grid_gen(puzzleset[x][1])
make_puzzle(puzzleset[x][0])
fill_puzzle(puzzleset[x][2])
pygame.display.update()

#main game loop it will run untill close is pressed

gameExit = False
completed= True
while not gameExit:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            gameExit = True
        if puzone == puzzleset[x][1]:
            completed = True
    #This function will check for User Input through Keyboard
    get_user_input()
    fill_puzzle(puzzleset[x][2])
    message_on_screen('jokerman.ttf', 60, 'KEMARU', DARKGREEN, WHITE, 275, 50)
    message_on_screen('arial.ttf', 10, 'ONLY NUMBERS 1-5 ARE ALLOWED', RED, WHITE, 425, 90)

    #makingrectangularbuttons
    make_button_rect(gameDisplay, LIGHTGREEN, GREEN, (625, 150, 100, 50), 'New Game', action='newgame')
    make_button_rect(gameDisplay, LIGHTBLUE, BLUE, (625, 250, 100, 50), 'Help', action='help')
    make_button_rect(gameDisplay, LIGHTRED, RED, (625, 350, 100, 50), 'Exit', action='quit')
    make_button_rect(gameDisplay, GREY, GREY, (600, 50, 110, 50),'Help Used: '+str(a))
    make_puzzle(puzzleset[x][0])
    fill_puzzle(puzzleset[x][2])
    compare_puzzle()
    pygame.display.update()
#Screen Message while exiting the Game
if gameExit:
    message_to_screen('Bye!', RED,600,475)
    pygame.display.update()
# Close the window and quit
pygame.quit()
quit()

#Thanks for playing the game